"""Lifetime branch-efficiency calculation shared by the POS UI and sync."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple


FORMULA_VERSION = 1
PROFIT_RATE = 0.35
STOCK_PENALTY_RATE = 0.65


def _table_exists(conn: sqlite3.Connection, table: str) -> bool:
    row = conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=? LIMIT 1",
        (table,),
    ).fetchone()
    return row is not None


def _scalar(conn: sqlite3.Connection, sql: str, args: Tuple[Any, ...] = ()) -> float:
    row = conn.execute(sql, args).fetchone()
    try:
        return float((row[0] if row else 0.0) or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _reservation_missing_payments(conn: sqlite3.Connection) -> float:
    if not _table_exists(conn, "reservations"):
        return 0.0
    try:
        rows = conn.execute(
            """
            SELECT r.id, COALESCE(r.paid_amount, 0) AS paid_amount,
                   COALESCE((
                       SELECT SUM(m.unit_price)
                         FROM movements m
                        WHERE m.direction IN ('RESERVE_PAY', 'DELIVER_PAY')
                          AND (m.note = 'عربون حجز #' || r.id
                               OR m.note LIKE '%' || '#' || r.id)
                   ), 0) AS recorded_amount
              FROM reservations r
            """
        ).fetchall()
    except sqlite3.OperationalError:
        return 0.0
    missing = 0.0
    for row in rows:
        paid = float(row[1] or 0.0)
        recorded = float(row[2] or 0.0)
        if paid > recorded:
            missing += paid - recorded
    return missing


def _net_sales_income_unscoped(conn: sqlite3.Connection) -> float:
    bills_total = 0.0
    if _table_exists(conn, "bills"):
        bills_total = _scalar(
            conn,
            """
            SELECT COALESCE(SUM(
                CASE
                    WHEN COALESCE(bill_type, 'SALE') = 'SALE' THEN total
                    WHEN bill_type = 'RETURN' THEN -ABS(total)
                    WHEN bill_type = 'EXCHANGE' THEN total
                    ELSE 0
                END
            ), 0)
              FROM bills
             WHERE UPPER(COALESCE(status, 'CONFIRMED')) != 'VOID'
            """,
        )
    reservation_total = 0.0
    if _table_exists(conn, "movements"):
        reservation_total = _scalar(
            conn,
            """
            SELECT COALESCE(SUM(
                CASE
                    WHEN direction IN ('RESERVE_PAY', 'DELIVER_PAY') THEN unit_price
                    WHEN direction = 'RESERVE_REFUND' THEN -ABS(unit_price)
                    ELSE 0
                END
            ), 0)
              FROM movements
             WHERE direction IN ('RESERVE_PAY', 'DELIVER_PAY', 'RESERVE_REFUND')
            """,
        )
    return bills_total + reservation_total + _reservation_missing_payments(conn)


def _scoped_total(conn: sqlite3.Connection, table: str, value_sql: str, where_sql: str, args: Tuple[Any, ...]) -> float:
    return _scalar(conn, f"SELECT COALESCE(SUM({value_sql}), 0) FROM {table} WHERE {where_sql}", args)


def _computed_shift_income(conn: sqlite3.Connection, shift: Dict[str, Any]) -> float:
    sid = int(shift["id"])
    started = str(shift.get("started_at") or "")
    ended = str(shift.get("ended_at") or datetime.now().isoformat(timespec="seconds"))
    bill_scope = "(shift_id=? OR (shift_id IS NULL AND created_at>=? AND created_at<=?))"
    movement_scope = "(m.shift_id=? OR (m.shift_id IS NULL AND m.ts>=? AND m.ts<=?))"
    args = (sid, started, ended)
    sales = _scoped_total(
        conn, "bills", "total",
        f"{bill_scope} AND COALESCE(bill_type,'SALE')='SALE' AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID'",
        args,
    )
    returns = _scoped_total(
        conn, "bills", "total",
        f"{bill_scope} AND bill_type='RETURN' AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID'",
        args,
    )
    exchanges = _scoped_total(
        conn, "bills", "total",
        f"{bill_scope} AND bill_type='EXCHANGE' AND UPPER(COALESCE(status,'CONFIRMED'))!='VOID'",
        args,
    )
    reservation_money = _scalar(
        conn,
        f"""
        SELECT COALESCE(SUM(CASE
            WHEN m.direction IN ('RESERVE_PAY','DELIVER_PAY') THEN m.unit_price
            WHEN m.direction='RESERVE_REFUND' THEN -ABS(m.unit_price)
            ELSE 0 END), 0)
          FROM movements m
         WHERE {movement_scope}
           AND m.direction IN ('RESERVE_PAY','DELIVER_PAY','RESERVE_REFUND')
        """,
        args,
    )
    cross_shift_voids = _scalar(
        conn,
        f"""
        SELECT COALESCE(SUM(m.unit_price), 0)
          FROM movements m
     LEFT JOIN bills b ON b.id=m.bill_id
         WHERE {movement_scope}
           AND m.direction='VOID_PAY'
           AND NOT (
                b.id IS NOT NULL AND (
                    (b.shift_id IS NOT NULL AND m.shift_id IS NOT NULL AND b.shift_id=m.shift_id)
                    OR (b.shift_id IS NULL AND b.created_at>=? AND b.created_at<=?)
                )
           )
        """,
        (*args, started, ended),
    )
    missing = 0.0
    try:
        rows = conn.execute(
            f"""
            SELECT r.id, COALESCE(r.paid_amount,0), COALESCE((
                SELECT SUM(m.unit_price) FROM movements m
                 WHERE m.direction IN ('RESERVE_PAY','DELIVER_PAY')
                   AND (m.note='عربون حجز #' || r.id OR m.note LIKE '%' || '#' || r.id)
            ),0)
              FROM reservations r WHERE {bill_scope}
            """,
            args,
        ).fetchall()
        missing = sum(max(0.0, float(r[1] or 0.0) - float(r[2] or 0.0)) for r in rows)
    except sqlite3.OperationalError:
        pass
    return sales - returns + exchanges + reservation_money - cross_shift_voids + missing


def _net_sales_income(conn: sqlite3.Connection) -> float:
    if not _table_exists(conn, "shifts"):
        return _net_sales_income_unscoped(conn)
    shifts = conn.execute("SELECT * FROM shifts ORDER BY started_at ASC, id ASC").fetchall()
    if not shifts:
        return _net_sales_income_unscoped(conn)
    total = 0.0
    for row in shifts:
        shift = dict(row)
        if str(shift.get("status") or "").upper() == "CLOSED":
            try:
                summary = json.loads(str(shift.get("summary_json") or ""))
            except Exception:
                summary = None
            if isinstance(summary, dict) and (
                "cash_collected" in summary or "visa_collected" in summary
            ):
                total += float(summary.get("cash_collected") or 0.0)
                total += float(summary.get("visa_collected") or 0.0)
                continue
        total += _computed_shift_income(conn, shift)
    return total


def _remaining_stock_value(conn: sqlite3.Connection) -> float:
    if not _table_exists(conn, "stocks"):
        return 0.0
    return _scalar(
        conn,
        """
        SELECT COALESCE(SUM(CASE WHEN count > 0 THEN count * unit_price ELSE 0 END), 0)
          FROM stocks
        """,
    )


def _net_received_stock_value(conn: sqlite3.Connection) -> float:
    if not _table_exists(conn, "movements"):
        return 0.0
    return _scalar(
        conn,
        """
        SELECT COALESCE(SUM(
            CASE
                WHEN UPPER(COALESCE(m.direction, '')) IN
                     ('IN', 'ADJUST_IN', 'TRANSFER_IN', 'SHIPMENT_RECEIVED')
                    THEN ABS(COALESCE(m.qty, 0)) * COALESCE(m.unit_price, 0)
                WHEN UPPER(COALESCE(m.direction, '')) = 'ADJUST_OUT'
                    THEN -ABS(COALESCE(m.qty, 0)) * COALESCE(m.unit_price, 0)
                WHEN UPPER(COALESCE(m.direction, '')) = 'TRANSFER_OUT'
                    THEN -ABS(COALESCE(m.qty, 0)) * COALESCE(m.unit_price, 0)
                WHEN UPPER(COALESCE(m.direction, '')) = 'OUT'
                     AND COALESCE(b.bill_type, '') IN
                         ('WAREHOUSE_RETURN', 'BRANCH_TRANSFER_REQUEST')
                    THEN -ABS(COALESCE(m.qty, 0)) * COALESCE(m.unit_price, 0)
                ELSE 0
            END
        ), 0)
          FROM movements m
     LEFT JOIN bills b ON b.id = m.bill_id
        """,
    )


def _spec_key(item_type: Any, school: Any, color: Any, size: Any) -> Tuple[str, str, str, str]:
    return tuple(str(v or "").strip().casefold() for v in (item_type, school, color, size))  # type: ignore[return-value]


def _fully_paid_pending(conn: sqlite3.Connection) -> Dict[str, Any]:
    out: Dict[str, Any] = {
        "fully_paid_pending_count": 0,
        "fully_paid_pending_qty": 0,
        "fully_paid_pending_value": 0.0,
        "fully_paid_deliverable_stock_value": 0.0,
    }
    if not _table_exists(conn, "reservations"):
        return out
    rows = conn.execute(
        """
        SELECT item_type, school, color, size,
               COALESCE(qty, 0), COALESCE(total_amount, 0)
          FROM reservations
         WHERE status = 'معلق'
           AND COALESCE(total_amount, 0) > 0
           AND COALESCE(paid_amount, 0) + 0.000001 >= COALESCE(total_amount, 0)
        """
    ).fetchall()
    required: Dict[Tuple[str, str, str, str], int] = {}
    for row in rows:
        qty = max(0, int(row[4] or 0))
        required[_spec_key(row[0], row[1], row[2], row[3])] = (
            required.get(_spec_key(row[0], row[1], row[2], row[3]), 0) + qty
        )
        out["fully_paid_pending_count"] += 1
        out["fully_paid_pending_qty"] += qty
        out["fully_paid_pending_value"] += float(row[5] or 0.0)

    if required and _table_exists(conn, "stocks"):
        available: Dict[Tuple[str, str, str, str], List[Tuple[int, float]]] = {}
        for row in conn.execute(
            """
            SELECT item_type, school, color, size, count, unit_price
              FROM stocks
             WHERE count > 0
             ORDER BY id
            """
        ).fetchall():
            available.setdefault(_spec_key(row[0], row[1], row[2], row[3]), []).append(
                (max(0, int(row[4] or 0)), float(row[5] or 0.0))
            )
        deliverable_value = 0.0
        for key, needed in required.items():
            remaining = needed
            for count, price in available.get(key, []):
                if remaining <= 0:
                    break
                take = min(remaining, count)
                deliverable_value += take * price
                remaining -= take
        out["fully_paid_deliverable_stock_value"] = deliverable_value
    return out


def efficiency_band(value: Optional[float]) -> str:
    if value is None:
        return "unavailable"
    if value < 0:
        return "critical"
    if value < 15:
        return "low"
    if value < 25:
        return "medium"
    return "good"


def calculate_branch_efficiency(conn: sqlite3.Connection) -> Dict[str, Any]:
    net_sales_income = _net_sales_income(conn)
    remaining_stock_value = _remaining_stock_value(conn)
    net_received_stock_value = _net_received_stock_value(conn)
    numerator = (net_sales_income * PROFIT_RATE) - (
        remaining_stock_value * STOCK_PENALTY_RATE
    )
    efficiency_pct: Optional[float] = None
    if net_received_stock_value > 0.000001:
        efficiency_pct = (numerator / net_received_stock_value) * 100.0

    result: Dict[str, Any] = {
        "formula_version": FORMULA_VERSION,
        "profit_rate": PROFIT_RATE,
        "stock_penalty_rate": STOCK_PENALTY_RATE,
        "net_sales_income": net_sales_income,
        "remaining_stock_value": remaining_stock_value,
        "net_received_stock_value": net_received_stock_value,
        "efficiency_numerator": numerator,
        "efficiency_pct": efficiency_pct,
        "efficiency_band": efficiency_band(efficiency_pct),
    }
    result.update(_fully_paid_pending(conn))
    deliverable_value = float(result["fully_paid_deliverable_stock_value"] or 0.0)
    result["potential_delivery_gain_pct"] = (
        (deliverable_value * STOCK_PENALTY_RATE / net_received_stock_value) * 100.0
        if net_received_stock_value > 0.000001
        else None
    )
    return result
