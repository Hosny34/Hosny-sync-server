"""Atomic import of Warehouse definition bootstrap into a POS database."""
from __future__ import annotations

import sqlite3

TABLES = {
    'catalog': ('item_defaults','spec_history'),
    'price_profiles': ('price_profiles','price_profile_lines','price_profile_assignments','price_profile_manual_overrides'),
    'size_profiles': ('size_profiles',),
    'fabric_weights': ('fabric_weights',),
    'tombstones': ('deleted_catalog_definitions','deleted_catalog_specs'),
}
DELETE_ORDER = ('price_profile_manual_overrides','price_profile_assignments','price_profile_lines',
                'price_profiles','size_profiles','fabric_weights','spec_history','item_defaults',
                'deleted_catalog_specs','deleted_catalog_definitions')
INSERT_ORDER = ('item_defaults','spec_history','price_profiles','price_profile_lines',
                'price_profile_assignments','price_profile_manual_overrides','size_profiles',
                'fabric_weights','deleted_catalog_definitions','deleted_catalog_specs')
SCHEMA = (
    '''CREATE TABLE IF NOT EXISTS price_profiles(id INTEGER PRIMARY KEY AUTOINCREMENT,
       name TEXT NOT NULL UNIQUE,notes TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL)''',
    '''CREATE TABLE IF NOT EXISTS price_profile_lines(id INTEGER PRIMARY KEY AUTOINCREMENT,
       profile_id INTEGER NOT NULL,item_type TEXT NOT NULL,size TEXT NOT NULL,price REAL NOT NULL,
       created_at TEXT NOT NULL,updated_at TEXT NOT NULL,UNIQUE(profile_id,item_type,size))''',
    '''CREATE TABLE IF NOT EXISTS price_profile_assignments(id INTEGER PRIMARY KEY AUTOINCREMENT,
       item_type TEXT NOT NULL,school TEXT NOT NULL,color TEXT NOT NULL,profile_id INTEGER NOT NULL,
       updated_at TEXT NOT NULL,UNIQUE(item_type,school,color))''',
    '''CREATE TABLE IF NOT EXISTS price_profile_manual_overrides(id INTEGER PRIMARY KEY AUTOINCREMENT,
       branch_device TEXT NOT NULL DEFAULT '',item_type TEXT NOT NULL,school TEXT NOT NULL,
       color TEXT NOT NULL,size TEXT NOT NULL,manual_price REAL,note TEXT,created_at TEXT NOT NULL,
       updated_at TEXT NOT NULL,UNIQUE(branch_device,item_type,school,color,size))''',
    '''CREATE TABLE IF NOT EXISTS fabric_weights(id INTEGER PRIMARY KEY AUTOINCREMENT,
       item_type TEXT NOT NULL,size TEXT NOT NULL,weight_grams REAL NOT NULL,created_at TEXT NOT NULL,
       updated_at TEXT NOT NULL,UNIQUE(item_type,size))''',
    '''CREATE TABLE IF NOT EXISTS deleted_catalog_definitions(field TEXT NOT NULL,value TEXT NOT NULL,
       deleted_at TEXT NOT NULL,PRIMARY KEY(field,value))''',
    '''CREATE TABLE IF NOT EXISTS deleted_catalog_specs(item_type TEXT NOT NULL,school TEXT NOT NULL,
       color TEXT NOT NULL,size TEXT NOT NULL,deleted_at TEXT NOT NULL,
       PRIMARY KEY(item_type,school,color,size))''',
)


class DefinitionError(RuntimeError):
    pass


def validate(definitions):
    if not isinstance(definitions,dict) or definitions.get('schema_version') != 1:
        raise DefinitionError('Unsupported definition bootstrap version')
    if set(definitions) != {'schema_version',*TABLES}:
        raise DefinitionError('Incomplete definition bootstrap')
    flattened = {}
    for category,tables in TABLES.items():
        content = definitions.get(category)
        if not isinstance(content,dict) or set(content) != set(tables):
            raise DefinitionError('Definition bootstrap table mismatch')
        for table,rows in content.items():
            if not isinstance(rows,list) or any(not isinstance(row,dict) for row in rows):
                raise DefinitionError('Definition rows must be objects')
            flattened[table] = rows
    return flattened


def apply(conn: sqlite3.Connection, definitions) -> dict:
    rows_by_table = validate(definitions)
    if conn.in_transaction:
        raise DefinitionError('Definition import requires an independent transaction')
    conn.execute('BEGIN IMMEDIATE')
    try:
        for statement in SCHEMA:
            conn.execute(statement)
        for table in DELETE_ORDER:
            if conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone():
                conn.execute('DELETE FROM ' + table)
        imported = 0
        for table in INSERT_ORDER:
            rows = rows_by_table[table]
            if not conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone():
                if rows:
                    raise DefinitionError('POS schema lacks definition table ' + table)
                continue
            columns = {r[1] for r in conn.execute('PRAGMA table_info(' + table + ')')}
            for row in rows:
                names = [name for name in row if name in columns]
                if not names:
                    raise DefinitionError('No compatible columns for ' + table)
                conn.execute('INSERT INTO ' + table + '(' + ','.join(names) + ') VALUES(' +
                             ','.join('?' for _ in names) + ')', [row[name] for name in names])
                imported += 1
        conn.commit()
        return {'rows':imported}
    except BaseException:
        conn.rollback()
        raise
