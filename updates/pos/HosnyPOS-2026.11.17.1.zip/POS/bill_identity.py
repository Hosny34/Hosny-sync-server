"""Persisted bill identities and additive reservation migration.

No database is opened or migrated on import. Callers must save business rows and
outbox events in the SAME outer transaction as allocate_header().
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import uuid
from contextlib import contextmanager


class IdentityError(RuntimeError):
    pass


@contextmanager
def identity_transaction(conn):
    if not conn.in_transaction:
        conn.execute("BEGIN IMMEDIATE")
        try:
            yield
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        return
    name = "identity_" + uuid.uuid4().hex
    conn.execute("SAVEPOINT " + name)
    try:
        yield
        conn.execute("RELEASE SAVEPOINT " + name)
    except BaseException:
        conn.execute("ROLLBACK TO SAVEPOINT " + name)
        conn.execute("RELEASE SAVEPOINT " + name)
        raise


def initialize_identity_schema(conn):
    # executescript would commit an outer transaction implicitly.
    statements = (
        """CREATE TABLE IF NOT EXISTS bill_number_sequences(
            branch_id TEXT NOT NULL, season_id TEXT NOT NULL, bill_type TEXT NOT NULL,
            last_number INTEGER NOT NULL CHECK(last_number>=0),
            PRIMARY KEY(branch_id,season_id,bill_type))""",
        """CREATE TABLE IF NOT EXISTS bill_identity_headers(
            header_uuid TEXT PRIMARY KEY, branch_id TEXT NOT NULL,
            season_id TEXT NOT NULL, generation_id TEXT NOT NULL,
            bill_type TEXT NOT NULL, number INTEGER NOT NULL CHECK(number>0),
            request_id TEXT NOT NULL, content_digest TEXT NOT NULL,
            legacy_group_key TEXT,
            UNIQUE(branch_id,season_id,bill_type,number),
            UNIQUE(branch_id,season_id,request_id))""",
        """CREATE TABLE IF NOT EXISTS reservation_bill_links(
            reservation_id INTEGER PRIMARY KEY, header_uuid TEXT NOT NULL
                REFERENCES bill_identity_headers(header_uuid))""",
    )
    with identity_transaction(conn):
        for statement in statements:
            conn.execute(statement)


def allocate_header(conn, *, branch_id, season_id, generation_id, bill_type,
                    request_id, content_digest):
    if not conn.in_transaction:
        raise IdentityError("Allocate identity inside the business transaction")
    values = (branch_id, season_id, generation_id, bill_type, request_id, content_digest)
    if not all(isinstance(v, str) and v.strip() for v in values):
        raise IdentityError("Identity scope, request and content digest are required")
    row = conn.execute("SELECT header_uuid,number,bill_type,content_digest,generation_id FROM bill_identity_headers WHERE branch_id=? AND season_id=? AND request_id=?",
                       (branch_id, season_id, request_id)).fetchone()
    if row:
        if row[2] != bill_type or row[3] != content_digest or row[4] != generation_id:
            raise IdentityError("Idempotency request reused with different content or generation")
        return {"header_uuid": row[0], "number": row[1], "existing": True}
    conn.execute("INSERT OR IGNORE INTO bill_number_sequences VALUES(?,?,?,0)",
                 (branch_id, season_id, bill_type))
    conn.execute("UPDATE bill_number_sequences SET last_number=last_number+1 WHERE branch_id=? AND season_id=? AND bill_type=?",
                 (branch_id, season_id, bill_type))
    number = conn.execute("SELECT last_number FROM bill_number_sequences WHERE branch_id=? AND season_id=? AND bill_type=?",
                          (branch_id, season_id, bill_type)).fetchone()[0]
    header_uuid = str(uuid.uuid4())
    conn.execute("INSERT INTO bill_identity_headers VALUES(?,?,?,?,?,?,?,?,NULL)",
                 (header_uuid, branch_id, season_id, generation_id, bill_type, number, request_id, content_digest))
    return {"header_uuid": header_uuid, "number": number, "existing": False}


def inspect_legacy_reservations(conn):
    columns = [r[1] for r in conn.execute("PRAGMA table_info(reservations)")]
    if not columns:
        return {"groups": [], "collisions": []}
    groups = {}
    for record in conn.execute("SELECT * FROM reservations ORDER BY id"):
        row = dict(zip(columns, record))
        key = str(row.get("reservation_group_uuid") or "").strip() or "legacy-" + str(row["id"])
        groups.setdefault(key, []).append(row)
    result, collisions = [], []
    for key, rows in groups.items():
        ids = [int(row["id"]) for row in rows]
        customers = {(str(row.get("customer") or "").strip(), str(row.get("customer_phone") or "").strip()) for row in rows}
        if len(customers) > 1:
            collisions.append({"group_key": key, "reservation_ids": ids,
                               "reason": "group contains different customer identities"})
        if min(ids) <= 0:
            collisions.append({"group_key": key, "reason": "nonpositive historical number"})
        result.append({"group_key": key, "number": min(ids), "reservation_ids": ids})
    return {"groups": result, "collisions": collisions}


def migrate_legacy_reservations(conn, *, branch_id, season_id, generation_id):
    """Map existing groups without changing any reservation/payment/stock row.

    Ambiguous customer grouping is reported, never repaired by silent merging.
    Scope must be supplied by authenticated enrollment in Phase 5, not UI labels.
    """
    if not all(isinstance(v, str) and v.strip() for v in (branch_id, season_id, generation_id)):
        raise IdentityError("Branch, season and generation are required")
    with identity_transaction(conn):
        report = inspect_legacy_reservations(conn)
        if report["collisions"]:
            return {"migrated": False, **report}
        initialize_identity_schema(conn)
        for group in report["groups"]:
            request_id = "legacy-reservation:" + generation_id + ":" + group["group_key"]
            digest = hashlib.sha256(json.dumps(group, sort_keys=True).encode()).hexdigest()
            existing = conn.execute("SELECT header_uuid,number,content_digest FROM bill_identity_headers WHERE branch_id=? AND season_id=? AND request_id=?",
                                    (branch_id, season_id, request_id)).fetchone()
            if existing:
                if existing[1] != group["number"] or existing[2] != digest:
                    raise IdentityError("Legacy group changed after identity migration")
                header_uuid = existing[0]
            else:
                header_uuid = str(uuid.uuid4())
                try:
                    conn.execute("INSERT INTO bill_identity_headers VALUES(?,?,?,?,?,?,?,?,?)",
                                 (header_uuid, branch_id, season_id, generation_id, "RESERVATION",
                                  group["number"], request_id, digest, group["group_key"]))
                except sqlite3.IntegrityError as exc:
                    raise IdentityError("Historical visible bill number collision; manual review required") from exc
            for reservation_id in group["reservation_ids"]:
                old = conn.execute("SELECT header_uuid FROM reservation_bill_links WHERE reservation_id=?", (reservation_id,)).fetchone()
                if old and old[0] != header_uuid:
                    raise IdentityError("Reservation already belongs to a different bill")
                conn.execute("INSERT OR IGNORE INTO reservation_bill_links VALUES(?,?)", (reservation_id, header_uuid))
        # Include all issued line IDs, even deleted historical high-water marks.
        highest = max((g["number"] for g in report["groups"]), default=0)
        if conn.execute("SELECT 1 FROM sqlite_master WHERE name='sqlite_sequence'").fetchone():
            seq = conn.execute("SELECT seq FROM sqlite_sequence WHERE name='reservations'").fetchone()
            if seq:
                highest = max(highest, int(seq[0]))
        conn.execute("INSERT INTO bill_number_sequences VALUES(?,?, 'RESERVATION',?) ON CONFLICT(branch_id,season_id,bill_type) DO UPDATE SET last_number=MAX(last_number,excluded.last_number)",
                     (branch_id, season_id, highest))
        return {"migrated": True, **report}


def reservation_scope(conn):
    """Persist a local legacy scope until authenticated season adoption.

    This is not enrollment: the display name is never used as authority. The
    subsequent enrollment step must explicitly adopt this scope, not allocate
    new numbers for existing bills.
    """
    with identity_transaction(conn):
        conn.execute('''CREATE TABLE IF NOT EXISTS bill_identity_local_scope(
            singleton INTEGER PRIMARY KEY CHECK(singleton=1), branch_id TEXT NOT NULL,
            season_id TEXT NOT NULL,generation_id TEXT NOT NULL,migrated INTEGER NOT NULL DEFAULT 0)''')
        row = conn.execute('SELECT branch_id,season_id,generation_id,migrated FROM bill_identity_local_scope').fetchone()
        if row is None:
            device = conn.execute('SELECT device_uuid FROM device_identity WHERE id=1').fetchone()
            branch = str(device[0] or '') if device else ''
            conn.execute('INSERT INTO bill_identity_local_scope VALUES(1,?,?,?,0)',
                         (branch or 'local-' + str(uuid.uuid4()), 'legacy-unassigned', str(uuid.uuid4())))
            row = conn.execute('SELECT branch_id,season_id,generation_id,migrated FROM bill_identity_local_scope').fetchone()
        scope = dict(zip(('branch_id','season_id','generation_id'), row[:3]))
        if not row[3]:
            report = migrate_legacy_reservations(conn, **scope)
            if not report['migrated']:
                raise IdentityError('Historical reservation groups require review: ' + json.dumps(report['collisions']))
            conn.execute('UPDATE bill_identity_local_scope SET migrated=1')
        return scope


def adopt_enrolled_scope(conn, *, branch_id, season_id, generation_id):
    """Atomically bind temporary local identities to authenticated authority."""
    if not all(str(value or '').strip() for value in (branch_id, season_id, generation_id)):
        raise IdentityError('Authenticated branch, season and generation are required')
    with identity_transaction(conn):
        scope = reservation_scope(conn)
        if scope == {'branch_id': branch_id, 'season_id': season_id,
                     'generation_id': generation_id}:
            return scope
        conflicts = conn.execute(
            '''SELECT bill_type,number,COUNT(*) FROM bill_identity_headers
               GROUP BY bill_type,number HAVING COUNT(*)>1''').fetchall()
        if conflicts:
            raise IdentityError('Local bill-number collisions must be reviewed before enrollment')
        conn.execute(
            'UPDATE bill_identity_headers SET branch_id=?,season_id=?,generation_id=?',
            (branch_id, season_id, generation_id))
        conn.execute('DELETE FROM bill_number_sequences')
        conn.execute(
            '''INSERT INTO bill_number_sequences(branch_id,season_id,bill_type,last_number)
               SELECT ?,?,bill_type,MAX(number) FROM bill_identity_headers GROUP BY bill_type''',
            (branch_id, season_id))
        conn.execute(
            '''UPDATE bill_identity_local_scope SET branch_id=?,season_id=?,generation_id=?,migrated=1
               WHERE singleton=1''', (branch_id, season_id, generation_id))
        return {'branch_id': branch_id, 'season_id': season_id,
                'generation_id': generation_id}


def link_reservation(conn, reservation_id, header_uuid):
    if not conn.in_transaction:
        raise IdentityError('Link reservation inside its business transaction')
    old = conn.execute('SELECT header_uuid FROM reservation_bill_links WHERE reservation_id=?',
                       (reservation_id,)).fetchone()
    if old and old[0] != header_uuid:
        raise IdentityError('Reservation cannot move to a different bill identity')
    conn.execute('INSERT OR IGNORE INTO reservation_bill_links VALUES(?,?)', (reservation_id,header_uuid))


def numbered_reservations(conn, rows):
    rows = [dict(row) for row in rows]
    if not rows:
        return rows
    reservation_scope(conn)
    ids = [int(row['id']) for row in rows]
    identities = {}
    for offset in range(0,len(ids),500):
        batch = ids[offset:offset+500]
        marks = ','.join('?' for _ in batch)
        for row in conn.execute('SELECT l.reservation_id,h.header_uuid,h.number,h.branch_id,h.season_id,h.generation_id '
                'FROM reservation_bill_links l JOIN bill_identity_headers h ON h.header_uuid=l.header_uuid '
                f'WHERE l.reservation_id IN ({marks})', batch):
            identities[row[0]] = dict(zip(('bill_header_uuid','bill_number','bill_branch_id','bill_season_id','bill_generation_id'), row[1:]))
    for row in rows:
        identity = identities.get(int(row['id']))
        if identity is None:
            raise IdentityError('Reservation has no persisted bill identity; migration review required')
        row.update(identity)
    return rows
