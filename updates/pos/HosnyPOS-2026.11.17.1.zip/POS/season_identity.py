"""Persistent POS database-generation identity and local write fence."""
from __future__ import annotations

import sqlite3
import uuid

PROTOCOL_VERSION = 1
WRITABLE = 'ACTIVE'
BLOCKED = {'NEEDS_ENROLLMENT','NEEDS_DEFINITIONS','STALE','PAUSED'}


class SeasonIdentityError(RuntimeError):
    pass


def initialize(conn: sqlite3.Connection) -> None:
    conn.execute('''CREATE TABLE IF NOT EXISTS pos_season_identity(
        singleton INTEGER PRIMARY KEY CHECK(singleton=1),generation_id TEXT NOT NULL,
        generation_secret TEXT NOT NULL,assigned_season_id TEXT,
        assigned_branch_id TEXT,
        protocol_version INTEGER NOT NULL,status TEXT NOT NULL,
        definition_revision INTEGER NOT NULL DEFAULT 0,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
    columns = {row[1] for row in conn.execute('PRAGMA table_info(pos_season_identity)')}
    if 'assigned_season_name' not in columns:
        conn.execute('ALTER TABLE pos_season_identity ADD COLUMN assigned_season_name TEXT')
    if 'assigned_branch_id' not in columns:
        conn.execute('ALTER TABLE pos_season_identity ADD COLUMN assigned_branch_id TEXT')


def get(conn: sqlite3.Connection):
    initialize(conn)
    row = conn.execute('SELECT * FROM pos_season_identity WHERE singleton=1').fetchone()
    return dict(row) if row else None


def ensure_candidate(conn: sqlite3.Connection):
    identity = get(conn)
    if identity:
        return identity
    conn.execute("INSERT INTO pos_season_identity(singleton,generation_id,generation_secret,protocol_version,status) "
                 "VALUES(1,?,?,?,'NEEDS_ENROLLMENT')",
                 (str(uuid.uuid4()),uuid.uuid4().hex + uuid.uuid4().hex,PROTOCOL_VERSION))
    return get(conn)


def activate(conn: sqlite3.Connection, season_id: str, start_seq: int,
             season_name: str | None = None, branch_id: str | None = None) -> None:
    if not season_id:
        raise SeasonIdentityError('Server did not assign a season')
    conn.execute("UPDATE pos_season_identity SET assigned_season_id=?,assigned_season_name=?,assigned_branch_id=?,"
                 "status='ACTIVE',updated_at=CURRENT_TIMESTAMP",
                 (season_id, season_name, branch_id))
    conn.execute("UPDATE sync_state SET last_pulled_seq=MAX(last_pulled_seq,?) WHERE channel='main'", (int(start_seq),))


def set_status(conn: sqlite3.Connection, status: str) -> None:
    initialize(conn)
    conn.execute('UPDATE pos_season_identity SET status=?,updated_at=CURRENT_TIMESTAMP WHERE singleton=1',
                 (status,))


def set_definition_revision(conn: sqlite3.Connection, revision: int) -> None:
    conn.execute('UPDATE pos_season_identity SET definition_revision=?,updated_at=CURRENT_TIMESTAMP WHERE singleton=1',
                 (int(revision),))


def assert_writable(conn: sqlite3.Connection) -> None:
    identity = get(conn)
    if identity and (identity['status'] != WRITABLE
                     or not identity.get('assigned_season_id')
                     or not identity.get('generation_id')
                     or identity.get('protocol_version') != PROTOCOL_VERSION):
        raise SeasonIdentityError(
            'This POS database is not active for the current season. Synchronize a fresh database authorized by the manager.')


def headers(identity) -> dict:
    if not identity:
        return {}
    return {'X-Season-Protocol':str(identity['protocol_version']),
            'X-Database-Generation':identity['generation_id'],
            'X-Generation-Token':identity['generation_secret']}
